package engine;

public interface ModelListener {

	
	
	public void onMove() ;
	public void onAttack();
	public void onCastAbilityDirec();
	public void onCastAbilityPoint();
	public void onCastAbilityElse();
	public void onCastLeaderAbility();
	public void onendturn();

}
